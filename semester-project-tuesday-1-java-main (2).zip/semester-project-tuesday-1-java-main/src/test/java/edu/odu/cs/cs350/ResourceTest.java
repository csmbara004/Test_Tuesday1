package edu.odu.cs.cs350;

import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertTrue;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;


public class ResourceTest {
    private Resource resource; //to test

    @BeforeEach
    public void setUp()
    {
    }

    @Test
    public void testResource()
    {
        resource = new Resource();
        assertNotNull(resource.getFoundOn(), "foundOn should be initialized");
        assertTrue(resource.getFoundOn().isEmpty(), "foundOn should start empty");
    }

}