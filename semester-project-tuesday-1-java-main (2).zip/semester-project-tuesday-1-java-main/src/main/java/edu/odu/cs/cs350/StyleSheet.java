package edu.odu.cs.cs350;

// Class will be used to set our Resource to StyleSheet

public class StyleSheet extends Resource {
    
    public StyleSheet()
    {
        this.setTypeOfResource(ResourceKind.STYLESHEET);
    }
}
