package edu.odu.cs.cs350;

import java.io.BufferedWriter;
import java.io.IOException;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;

public class ReportManager {

    private String baseFilename;
    private Website site; //Need class Website
    
    public ReportManager()
    {
        this.baseFilename = null;
        this.site = null;
    }

    public void setSourceData(Website sourceData)
    {
        this.site = sourceData;
    }

    public void determineBaseFileName()
    {
        LocalDateTime now = LocalDateTime.now();
        DateTimeFormatter formatter = DateTimeFormatter.ofPattern("YYYYMMDD-hhmmss");

        this.baseFilename = now.format(formatter) + "-summary";
    }

    public void writeReportNames(BufferedWriter nameWriter)
        throws IOException
    {
        String reportName = String.format("%s.txt", this.baseFilename);
        nameWriter.write(reportName);

        reportName = String.format("%s.json", this.baseFilename);
        nameWriter.write(reportName);

        reportName = String.format("%s.xlsx", this.baseFilename);
        nameWriter.write(reportName);

        nameWriter.flush();
    }

    public void writeAll()
        throws /*Various Exceptions*/
    {
        ReportWriter writer = null;
        
        writer = new TextReportWriter();
        writer.setSourceData(this.site);
        writer.setBaseName(this.baseFilename);
        writer.write();

        writer = new JSONReportWriter();
        writer.setSourceData(this.site);
        writer.setBaseName(this.baseFilename);
        writer.write();

        writer = new ExcelReportWriter();
        writer.setSourceData(this.site);
        writer.setBaseName(this.baseFilename);
        writer.write();
    }
    
}
