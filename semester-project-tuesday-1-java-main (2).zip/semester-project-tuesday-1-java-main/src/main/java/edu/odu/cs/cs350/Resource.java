package edu.odu.cs.cs350;

import java.util.List;
import java.util.ArrayList;
import java.util.ListIterator;
import java.util.Iterator;
import java.nio.file.Path;
import java.net.URL;
import java.util.List;
import java.util.ArrayList;


/**
 * This is a Brute Force Prime Number Generator. It is intentionally
 * inefficient.
 * <p>
 * There exist far more appropriate methods to identify prime numbers.
 */

public class Resource {
    private Path path;
    private String url;
    private Locality location;
    private ResourceKind typeOfResource;
    private ArrayList<HTMLDocument> foundOn; 
    private long sizeOfFile;
    int x;
    /**
     * Ordered list of known primes.
     */
     public Resource() {
        this.foundOn = new ArrayList<>();
    }

    public ArrayList<HTMLDocument> getFoundOn() {
        return foundOn;
    }

    public void setFoundOn(ArrayList<HTMLDocument> foundOn) {
        this.foundOn = foundOn;
    }

    public int getX() {
        return x;
    }

    public void setX(int x) {
        this.x = x;
    }
 

    public enum ResourceKind{ 
        IMAGE,
        SCRIPT,
        STYLESHEET,
        ANCHOR,
        VIDEO,
        AUDIO,
        ARCHIVE,
        OTHER
    }
    public enum  Locality  {
      INTERNAL,
      INTRAPAGE,
      EXTERNAL
    }
 
    public Path getPath() {
        return path;
    }
    public void setPath(Path path) {
        this.path=path;
    }
    public String getUrl() {
        return url;
    }
    public void setUrl(String url) {
        this.url = url;
    }
    
    
    public  Locality getLocation() {
        return location;
    }
    public  void setLocation(Locality location) {
        this.location = location;
    }

    public ResourceKind getTypeOfResource() {
        return typeOfResource;
    }

 
 
   
   

 
 

   
     public void setTypeOfResource(ResourceKind typeOfResource) {
        this.typeOfResource = typeOfResource;
    }

    public long getSizeOfFile() {
        return sizeOfFile;
    }

    public void setSizeOfFile(long sizeOfFile) {
        this.sizeOfFile = sizeOfFile;
    }

     @Override
    public boolean equals(Object obj) {
        if (!(obj instanceof Resource)) {
            return false;
        }

        Resource other = (Resource) obj;

        return path.equals(other.path)
            && url.toString().equals(other.url.toString())
            && location == other.location
            && typeOfResource == other.typeOfResource
            && sizeOfFile == other.sizeOfFile;
    }

    /**
     * Compute a hashcode (use the same attributes used by equals).
     */
    @Override
    public int hashCode()
    {
         return path.hashCode() + url.toString().hashCode() + (int) sizeOfFile;
    }

   
    @Override
    public String toString()
    {
      return String.format("Resource[%s | %s | %s | %s | %d bytes]",
            path, typeOfResource, location, url, sizeOfFile);
    }
    
}
