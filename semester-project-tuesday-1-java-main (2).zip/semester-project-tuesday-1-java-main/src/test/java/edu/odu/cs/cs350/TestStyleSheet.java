package edu.odu.cs.cs350;
import edu.odu.cs.cs350.StyleSheet;
import edu.odu.cs.cs350.Resource;

import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

//This file tests if Stylesheet is applied as a ResourceKind

public class TestStyleSheet {
    @Test
    public void testStyleSheetExist(){ 
        StyleSheet newstyle = new StyleSheet();
        assertEquals(Resource.ResourceKind.STYLESHEET, newstyle.getTypeOfResource());
    }   

}
