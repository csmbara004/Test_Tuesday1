package edu.odu.cs.cs350;
import edu.odu.cs.cs350.Image;
import edu.odu.cs.cs350.Resource;


import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

//Updated test file for Image ResourceKind
public class TestImage {
    @Test
    public void testImageExists() {
        Image img = new Image();
        assertEquals(Resource.ResourceKind.IMAGE, img.getTypeOfResource());
    }
}
