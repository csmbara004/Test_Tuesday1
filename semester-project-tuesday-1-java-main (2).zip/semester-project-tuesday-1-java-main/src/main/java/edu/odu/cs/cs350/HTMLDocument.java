package edu.odu.cs.cs350;

public class HTMLDocument {

}
