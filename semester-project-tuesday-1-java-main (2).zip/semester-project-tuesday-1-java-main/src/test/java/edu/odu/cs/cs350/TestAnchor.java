package edu.odu.cs.cs350;

import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.BeforeEach;


//This will be my file to test Anchor.java

public class TestAnchor {

     @BeforeEach
    public void setUp()
    {
    }

    @Test
    public void testAnchor()
    {
        fail("Not Implemented.");

    }
}
