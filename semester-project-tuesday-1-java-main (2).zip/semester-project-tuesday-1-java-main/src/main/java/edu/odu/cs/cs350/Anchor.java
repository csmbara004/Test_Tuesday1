package edu.odu.cs.cs350;
//Class will be used to classify our Resouse as an Anchor 
//Aswell as classify our linktype

public class Anchor {
    
}
