package edu.odu.cs.cs350;

import java.io.BufferedReader;
import java.io.IOException;
import java.nio.file.Path;
import java.util.ArrayList;
import java.util.List;
import java.net.URL;

public class WebsiteBuilder {
    private Path path;
    private List<URL> urls;

    public WebsiteBuilder() {
        // Initialize with default values
        this.path = null;
        this.urls = new ArrayList<>();
    }

    // Implement the various "with" methods
    public WebsiteBuilder withPath(Path path) {
        this.path = path;
        return this;
    }

    public WebsiteBuilder withURLs(List<URL> urls) {
        this.urls = urls;
        return this;
    }

    // Implement walkDirectory (just a placeholder method here)
    private List<Path> walkDirectory() throws IOException {
        // Placeholder: Logic to walk the directory and return a list of Path objects
        return new ArrayList<>();
    }

    // Implement removeNonHTMLFiles
    private List<Path> pruneNonHTMLFiles(List<Path> files) {
        // Placeholder: Logic to remove non-HTML files from the list
        List<Path> htmlFiles = new ArrayList<>();
        for (Path file : files) {
            if (file.toString().endsWith(".html") || file.toString().endsWith(".htm")) {
                htmlFiles.add(file);
            }
        }
        return htmlFiles; 
    }

    public Website build() throws IOException {
        // Walk the directory to get all files
        List<Path> files = walkDirectory();

        // Prune non-HTML files
        List<Path> prunedFiles = pruneNonHTMLFiles(files);

        // Parse HTML documents
        List<HTMLDocument> parsedDocuments = new ArrayList<>();
        for (Path htmlFile : prunedFiles) {
            try (BufferedReader buffer = new BufferedReader(new java.io.FileReader(htmlFile.toFile()))) {
                HTMLDocument doc = new HTMLDocumentBuilder()
                    .withContentFrom(buffer)
                    .withWebsiteBaseDir(this.path)  // needed for path normalization
                    .withWebsiteURLs(this.urls)  // needed for internal/external classification
                    .extractContent()  // exceptions can be thrown by this function
                    .build();

                parsedDocuments.add(doc);
            } catch (IOException e) {
                // Handle exception if a file can't be read
                System.err.println("Error reading file: " + htmlFile);
                e.printStackTrace();
            }
        }

        // Create the final Website object
        Website site = new Website(this.path, this.urls, parsedDocuments);

        return site;
    }
      public static class HTMLDocument {
        // Add fields/methods later
        
    }
}
