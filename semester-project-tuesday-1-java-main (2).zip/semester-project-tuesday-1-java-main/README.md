# Tuesday 1 - Java

| Name           | GitHub Username | Email            |
| :---           | :-------------- | :----            |
| Seth Huthmaker | themstwntdlmsv  | shuth001@odu.edu |
| Ethan Spruill  | BigE50          | espru002@odu.edu |
|Brianna Thomas  | BriaTheCreator  |Bthom083@odu.edu  |
| Andrew Morgan  | andrewmorganny  | amorg029@odu.edu | 
| Mohamed Barakat| cs_mbara004     | mbara004@odu.edu  |
| Anthony McFarlane|     DmnAnt    | amcfa010@odu.edu  |


# Team Contract

https://docs.google.com/document/d/1a74XR7xsDJ0QgSC5sQf_Gbd6_-djtlL-/edit?usp=sharing&ouid=115757911283174122558&rtpof=true&sd=true


# Design Notes

This section is used during the Phase 3 Design Brainstorming Session


# Dependencies

  - **Language:**
    - Java 11
  - **Libraries:**
    - org.jsoup:jsoup:1.16.1
    - org.apache.poi:poi:5.2.3+
    - org.apache.poi:poi-ooxml:5.2.3+
    - com.cedarsoftware:json-io:4.14.0 
