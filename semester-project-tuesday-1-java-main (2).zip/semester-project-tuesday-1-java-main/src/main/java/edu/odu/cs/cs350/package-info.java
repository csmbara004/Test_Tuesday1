/**
 * A collection of number-based examples.
 */
package edu.odu.cs.cs350;
