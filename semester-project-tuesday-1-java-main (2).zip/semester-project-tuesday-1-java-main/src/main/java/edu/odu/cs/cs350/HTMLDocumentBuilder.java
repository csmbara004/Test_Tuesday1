package edu.odu.cs.cs350;

import java.io.BufferedReader;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import java.net.URL;
import java.nio.file.Path;
import java.nio.file.Paths;

public class HTMLDocumentBuilder {
    private ArrayList<Anchor> anchors;
    private ArrayList<Image> images;
    private ArrayList<Script> scripts;
    private ArrayList<StyleSheet> stylesheets;

    private ArrayList<URL> baseSiteUrls;
    private Path baseDirectory;

    private BufferedReader readBuffer;

    public HTMLDocumentBuilder()
    {
        this.anchors = new ArrayList<>();
        this.images = new ArrayList<>();
        this.scripts = new ArrayList<>();
        this.stylesheets = new ArrayList<>();
        //...
        //...
        //...
    }

    //...
    // Implement withContentFrom (both variants)
    //...

    //...
    // Implement withBaseDirectory
    //...

    //...
    // Implement withBaseURLs
    //...

    List<Resource> extractAnchors()
        throws IOException, FileNotFoundException
    {
        SimpleHTMLParser parser = new SimpleHTMLParser("a", "href");
        List<String> extractedStrings = parser.extractAllURIs(this.readBuffer);

        // The URIs (URLs and Paths) are currently in string form.
        // As part of the analysis, they need to be converted to Resource objects

        //...

        this.anchors = ⋮

        return this.anchors;
    }

    List<Resource> extractImages()
        throws IOException, FileNotFoundException
    {
        SimpleHTMLParser parser = new SimpleHTMLParser("img", "src");
        List<String> extractedStrings = parser.extractAllURIs(this.readBuffer);

        // The URIs (URLs and Paths) are currently in string form.
        // As part of the analysis, they need to be converted to Resource objects

        //...
   
       this.images = new ArrayList<>();
        for (String uri : extractedStrings) {
            Resource resource = new Resource();
            resource.setUrl(uri);
            resource.setPath(this.baseDirectory);
            resource.setTypeOfResource(Resource.ResourceKind.IMAGE);
            this.images.add(new Image(resource));
        }

        return this.images;
    }

    List<Resource> extractScripts()
        throws IOException, FileNotFoundException
    {
        SimpleHTMLParser parser = new SimpleHTMLParser("script", "src");
        List<String> extractedStrings = parser.extractAllURIs(this.readBuffer);

        // The URIs (URLs and Paths) are currently in string form.
        // As part of the analysis, they need to be converted to Resource objects

        //...

        this.scripts = ⋮

        return this.scripts;
    }

    List<Resource> extractStyleSheets()
        throws IOException, FileNotFoundException
    {
        SimpleHTMLParser parser = new SimpleHTMLParser("link", "href");
        List<String> extractedStrings = parser.extractAllURIs(this.readBuffer);

        // The URIs (URLs and Paths) are currently in string form.
        // As part of the analysis, they need to be converted to Resource objects

        //...

        this.stylesheets = ⋮

        return this.stylesheets;
    }

    public HTMLDocumentBuilder extractContent()
        throws IOException, FileNotFoundException
    {
        this.extractAnchors();
        this.extractImages();
        this.extractScripts();
        this.extractStyleSheets();
    }

    //...
    // Implement build
    //...
    public HTMLDocument build() throws IOException {
        HTMLDocument HTMLDoc = new HTMLDocument();
        this.extractContent();
        HTMLDoc.setAnchors(anchors);
        HTMLDoc.setImages(images);
        HTMLDoc.setScripts(scripts);
        HTMLDoc.setStyleSheets(stylesheets);
        HTMLDoc.setBaseDirectory(this.baseDirectory);
        return HTMLDoc;
    }
}