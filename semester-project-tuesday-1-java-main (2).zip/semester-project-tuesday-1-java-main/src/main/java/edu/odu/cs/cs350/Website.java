package edu.odu.cs.cs350;
import java.net.URL;
import java.nio.file.Path;
import java.util.ArrayList;
import java.util.List;

public class Website {
    //List<OtherFile> otherFiles;
    Path localDirectory;
    List<HTMLDocument> pages;
    ArrayList<URL> urls;
      /**
     * Default constructor
     */
      public Website() {
        pages = new ArrayList<>();
      }

    public Website(Path path, ArrayList<URL> urls, List<HTMLDocument> HTMLDocuments) {
    this.localDirectory = path;
    this.urls = urls;
    this.pages = HTMLDocuments;
}
 
    public Website(Path localDirectory, List<HTMLDocument> pages) {
    this.localDirectory = localDirectory;
    this.pages = pages;
}
    //public List<OtherFile> getOtherFiles() {
   // return otherFiles;
//}

/**
 * Sets other types of files (HTML, CSS, Image(PNG), Image(JPG), plaintext, zip files, etc.)
 */
   // public void setOtherFiles(List<OtherFile> otherFiles) {
    //this.otherFiles = otherFiles;
//}

/**
 * Sets local directory function
 */
    public void setLocalDirectory(Path localDirectory) {
    this.localDirectory = localDirectory;
}
public void addPage(HTMLDocument page) {
    pages.add(page);
}

/**
 * Sets an HTML document list
 * @param pages the list of HTMLDocument objects
 */
public void setPages(List<HTMLDocument> pages) {
    this.pages = pages;
}

/**
 * Gets the local directory path
 * @return localDirectory
 */
public Path getLocalDirectory() {
    return localDirectory;
}

/**
 * Gets the list of HTMLDocument pages
 * @return pages
 */
public List<HTMLDocument> getPages() {
    return pages;
}



}