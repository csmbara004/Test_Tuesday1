package edu.odu.cs.cs350;
import edu.odu.cs.cs350.Script;
import edu.odu.cs.cs350.Resource;

import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

//This file makes sure that the Script Resource is applied

public class TestScript {
    @Test
    public void testScriptExists() {
        Script newscript = new Script();
        assertEquals(Resource.ResourceKind.SCRIPT, newscript.getTypeOfResource());
    }
}
