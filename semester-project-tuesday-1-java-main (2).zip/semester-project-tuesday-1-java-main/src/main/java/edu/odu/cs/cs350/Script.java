package edu.odu.cs.cs350;

//Class will be used to classify our Resource as Script

public class Script extends Resource {
    
    public Script()
    {
        this.setTypeOfResource(ResourceKind.SCRIPT);
    }
}
