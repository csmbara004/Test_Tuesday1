package edu.odu.cs.cs350;

//Class will be used to classify our Resource as Image

public class Image extends Resource {


    public Image() {
        this.setTypeOfResource(ResourceKind.IMAGE);
        
    }
    
        
    
}
