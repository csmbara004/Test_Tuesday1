package edu.odu.cs.cs350;

import java.util.List;
import java.util.Arrays;
import java.io.BufferedWriter;
import java.io.OutputStreamWriter;
import java.io.IOException;
import java.nio.file.Path;
import java.nio.file.Paths;

public class Driver {
    
    public static void main(String[] args) {
        // Handle user arguments
        String websitePath = args[0];

        // Grab the remaining arguments using a Java Stream
        List<String> urls = Arrays.stream(args)
            .skip(1)
            .toList();

        Website site = new WebsiteBuilder()
            .withPath(websitePath)
            .withURLs(urls)
            .build();

        ReportManager manager = new ReportManager();
        manager.setSourceData(site);

        // We want to control when this happens... since time does not pause.
        manager.determineBaseFileName();

        // Write the reports before writing the filenames.
        // If something goes wrong... we do not want to
        // output the filename for a report that was not generated
        manager.writeAll();

        try (BufferedWriter writer = new BufferedWriter(
                new OutputStreamWriter(System.out))) {
            manager.writeReportNames(writer);
        } catch (IOException e) {
            System.err.println("Error writing report names: " + e.getMessage());
        }
    }
}
